package com.example.turntabledemo;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Region;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.view.ViewCompat;

import java.util.ArrayList;
import java.util.List;

public class TurnTableView extends View {

    private Context context;
    private int screenWidth, screenHeight;

    private int initAngle = 0;

    private String[] strs = {"0", "1", "2", "3", "4", "5"};

    private int radius = 0;

    private int panNum = 6;

    private int diffRadius;

    private int verPanRadius;

    //旋转一圈所需要的时间
    private static final long ONE_WHEEL_TIME = 500;

    private Paint oddPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Paint evenPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Paint whitePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private TextPaint textPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);

    //坐标
    private int centerX, centerY;

    public TurnTableView(Context context) {
        this(context, null);
    }

    public TurnTableView(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public TurnTableView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        this.context = context;

        screenHeight = getResources().getDisplayMetrics().heightPixels;
        screenWidth = getResources().getDisplayMetrics().widthPixels;

        //60  240
        initAngle = 240;

        verPanRadius = 360 / panNum;

        diffRadius = verPanRadius / 2;

        //蓝色
        oddPaint.setColor(Color.rgb(188, 245, 255));

        //红色
        evenPaint.setColor(Color.rgb(253, 191, 192));

        //白色
        whitePaint.setColor(Color.WHITE);

        textPaint.setColor(Color.rgb(146, 66, 18));
        textPaint.setTextSize(Util.sp2px(context, 14));
        textPaint.setTextAlign(Paint.Align.CENTER);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        int minValue = Math.min(screenWidth, screenHeight);
        minValue -= Util.dip2px(context, 40) * 2;
        setMeasuredDimension(minValue, minValue);
    }

    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);
        centerX = (right - left) / 2;
        centerY = (bottom - top) / 2;
    }

    private List<Path> mPaths = new ArrayList<>();

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int paddingLeft = getPaddingLeft();
        int paddingRight = getPaddingRight();
        int paddingTop = getPaddingTop();
        int paddingBottom = getPaddingBottom();

        int width = getWidth() - paddingLeft - paddingRight;
        int height = getHeight() - paddingTop - paddingBottom;

        int minValue = Math.min(width, height);

        radius = minValue / 2;


        RectF rectF = new RectF(getPaddingLeft(), getPaddingTop(), width, height);

        int angle = initAngle;

        mPaths.clear();

        for (int i = 0; i < panNum; i++) {
            Path path = new Path();
            path.addArc(rectF, angle, verPanRadius);
            path.lineTo(width / 2, height / 2);
            if (i == 0) {
                canvas.drawPath(path, whitePaint);
//                canvas.drawArc(rectF, angle, verPanRadius, true, whitePaint);
            } else if (i % 2 == 0) {
//                canvas.drawArc(rectF, angle, verPanRadius, true, oddPaint);
                canvas.drawPath(path, oddPaint);
            } else {
//                canvas.drawArc(rectF, angle, verPanRadius, true, evenPaint);
                canvas.drawPath(path, evenPaint);
            }
            mPaths.add(path);
            angle += verPanRadius;
        }

        for (int i = 0; i < strs.length; i++) {
            drawText(initAngle, strs[i], centerX, centerY, textPaint, canvas);
            initAngle += verPanRadius;
        }

    }

    private void drawText(float startAngle, String str, int centerX, int centerY, TextPaint textPaint, Canvas canvas) {

        Path path = new Path();

        Paint paint = new Paint();
        Rect rect = new Rect();
        paint.getTextBounds(str, 0, str.length(), rect);

        int w = rect.width();
        int h = rect.height();

        int textPosition = radius - Util.dip2px(context, 30);

        int x = (int) (textPosition * Math.cos(Util.change(startAngle + 5))) + centerX;
        int y = (int) (textPosition * Math.sin(Util.change(startAngle + 5))) + centerY;

        int x1 = (int) (textPosition * Math.cos(Util.change(startAngle + verPanRadius - 5))) + centerX;
        int y1 = (int) (textPosition * Math.sin(Util.change(startAngle + verPanRadius - 5))) + centerY;

        path.moveTo(x, y);
        path.lineTo(x1, y1);

        int ax = x - x1;
        int ay = y - y1;

        int with = (int) Math.sqrt(ax * ax + ay * ay);

        ArrayList<String> charList = staticLayout(with, str);

        if (charList != null) {
            if (charList.size() == 1) {
                canvas.drawTextOnPath(charList.get(0), path, 0, 0, textPaint);
            } else {
                for (int i = 0; i < charList.size(); i++) {
                    // 换行时文字沿路径居中显示
                    canvas.drawTextOnPath(charList.get(i), path, 0, i * 50, textPaint);
                }
            }
        }
    }


    public ArrayList<String> staticLayout(int width, String text) {
        ArrayList<String> al = new ArrayList<>();
        int end = ((CharSequence) text).length();
        int next = 0;
        float[] measuredWidth = {0};
        while (next < end) {
            int bPoint = textPaint.breakText(text, next, end, true, width, measuredWidth);
            int spacePosition = 0;
            int enterPosition = 0;
            enterPosition = text.substring(next, next + bPoint).indexOf('\n');
            spacePosition = text.substring(next, next + bPoint).lastIndexOf(' ');
            if (enterPosition <= 0) {// 没有找到回车
                if (spacePosition <= 0) {// 没有空格
                    al.add(text.substring(next, next + bPoint));
                    next += bPoint;
                } else {// 有空格，最后一个空格处换行
                    al.add(text.substring(next, next + spacePosition + 1));
                    next += spacePosition + 1;
                }
            } else {// 有回车，第一个回车处换行
                al.add(text.substring(next, next + enterPosition));// 空格不打印出来，因为现实方框
                next += enterPosition + 1;
            }
        }
        return al;
    }


    /**
     * 开始转动
     *
     * @param pos 如果 pos = -1 则随机，如果指定某个值，则转到某个指定区域
     */
    protected void startRotate(int pos) {

        //Rotate lap.
        int lap = (int) (Math.random() * 10) + 3;

        Log.e("num", "num--lap---->" + lap);

        //Rotate angle.
        int angle = 0;

        if (pos < 0) {
            angle = (int) (Math.random() * 360);
        } else {

            int initPos = queryPosition();
            Log.e("initPos", "initPos--->" + initPos);

            if (pos > initPos) {
                angle = 360 - (pos - initPos) * verPanRadius;
            } else if (pos < initPos) {
                angle = (initPos - pos) * verPanRadius;
            }
        }

        int increaseDegree = lap * 360 + angle;
        long time = (lap + angle / 360) * ONE_WHEEL_TIME;
        int disRotate = increaseDegree + initAngle;

        ValueAnimator animator = ValueAnimator.ofInt(initAngle, disRotate);
        animator.setInterpolator(new AccelerateDecelerateInterpolator());
        animator.setDuration(time);
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                int updateValue = (int) animation.getAnimatedValue();
                initAngle = updateValue % 360;
                ViewCompat.postInvalidateOnAnimation(TurnTableView.this);
            }
        });

        animator.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                if (((TurnTableLayout) getParent()).getAnimationEndListener() != null) {
                    ((TurnTableLayout) getParent()).setStartBtnEnable(true);
                    ((TurnTableLayout) getParent()).setDelayTime(TurnTableLayout.DEFAULT_TIME_PERIOD);
                    ((TurnTableLayout) getParent()).getAnimationEndListener().endAnimation(queryPosition());
                }
            }
        });
        animator.start();
    }

    private int queryPosition() {
        initAngle = initAngle % 360;
        if (initAngle > 240) {
            return (360 - (initAngle - 240)) / verPanRadius;
        }
        return (240 - initAngle) / verPanRadius;
    }


    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float x = event.getX();
        float y = event.getY();
        Log.e("onTouchEvent", "x---->" + x);
        Log.e("onTouchEvent", "y---->" + y);
        Toast.makeText(getContext(), "x--->" + x + ",y----->" + y, Toast.LENGTH_SHORT).show();
        int index= curIndex(x, y);
        Log.e("index","index---"+index);
        return super.onTouchEvent(event);
    }

    private int curIndex(float x, float y) {
        int index = 0;
        for (int i = 0; i < mPaths.size(); i++) {
            if (pointIsInPath(x,y,mPaths.get(i))){
                index = i;
            }
        }
        return index;
    }

    private boolean pointIsInPath(float x, float y, Path path) {
        RectF bounds = new RectF();
        path.computeBounds(bounds, true);
        Region region = new Region();
        region.setPath(path, new Region((int) bounds.left, (int) bounds.top, (int) bounds.right, (int) bounds.bottom));

        return region.contains((int) x, (int) y);
    }
}
