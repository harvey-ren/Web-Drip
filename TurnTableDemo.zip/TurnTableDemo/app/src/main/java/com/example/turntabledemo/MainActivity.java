package com.example.turntabledemo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements TurnTableLayout.AnimationEndListener {

    private TurnTableLayout turnTableLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        turnTableLayout = (TurnTableLayout) findViewById(R.id.turnTableLayout);
        turnTableLayout.setAnimationEndListener(this);
    }

    public void rotation(View view) {
        int num = (int) (Math.random()*5);
        Log.e("num","num--random-->"+num);
        turnTableLayout.rotate(num, 100);
    }

    @Override
    public void endAnimation(int position) {
        Toast.makeText(this, "Position = " + position, Toast.LENGTH_SHORT).show();
    }
}