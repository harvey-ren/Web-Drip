package com.example.turntabledemo;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;

public class TurnTableLayout extends RelativeLayout {


    private Context context;

    private Paint backgroundPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Paint whitePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Paint yellowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private boolean isYellow = false;
    private int delayTime = 500;
    private ImageView startBtn;

    //屏幕的宽高
    private int screenWidth, screenHeight;

    //半径
    private int radius;

    //坐标
    private int circleX, circleY;

    //最小值
    private int minValue;

    //当前画布
    private Canvas canvas;

    private TurnTableView mTurnTableView;

    public static final int DEFAULT_TIME_PERIOD = 500;

    private static final String START_BTN_TAG = "startbtn";

    public TurnTableLayout(Context context) {
        this(context, null);
    }

    public TurnTableLayout(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public TurnTableLayout(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        Log.e("TurnTableLayout", "init");

        this.context = context;

        backgroundPaint.setColor(Color.rgb(255, 99, 99));

        whitePaint.setColor(Color.WHITE);
        yellowPaint.setColor(Color.YELLOW);

        screenWidth = getResources().getDisplayMetrics().widthPixels;
        screenHeight = getResources().getDisplayMetrics().heightPixels;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        Log.e("TurnTableLayout", "onMeasure");
        minValue = Math.min(screenWidth, screenHeight);
        setMeasuredDimension(minValue, minValue);
    }

    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);
        Log.e("TurnTableLayout", "onLayout");

        int centerX = (right - left) / 2;
        int centerY = (bottom - top) / 2;

        boolean panReady = false;

        for (int i = 0; i < getChildCount(); i++) {
            View child = getChildAt(i);
            if (child instanceof TurnTableView) {
                mTurnTableView = (TurnTableView) child;
                int turnTableWidth = child.getWidth();
                int turnTableHeight = child.getHeight();
                child.layout(centerX - turnTableWidth / 2, centerY - turnTableHeight / 2, centerX + turnTableWidth / 2, centerY + turnTableHeight / 2);
                panReady = true;
            }else if (child instanceof  ImageView){
                if (TextUtils.equals((String) child.getTag(), START_BTN_TAG)) {
                    startBtn = (ImageView) child;
                    int btnWidth = child.getWidth();
                    int btnHeight = child.getHeight();
                    child.layout(centerX - btnWidth / 2, centerY - btnHeight / 2, centerX + btnWidth / 2, centerY + btnHeight / 2);
                }
            }
        }

        if (!panReady){
            throw new RuntimeException("Have you add TurnTableView in LuckPanLayout element ?");
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        Log.e("TurnTableLayout", "onDraw");

        this.canvas = canvas;
        int paddingLeft = getPaddingLeft();
        int paddingRight = getPaddingRight();
        int paddingTop = getPaddingTop();
        int paddingBottom = getPaddingBottom();

        int width = getWidth() - paddingLeft - paddingRight;
        int height = getHeight() - paddingTop - paddingBottom;

        int minValue = Math.min(width, height);

        radius = minValue / 2;

        circleX = getWidth() / 2;
        circleY = getHeight() / 2;

        canvas.drawCircle(circleX, circleY, radius, backgroundPaint);

        drawSmallDot(isYellow);
    }

    private void drawSmallDot(boolean firstYellow) {
        int pointDistance = radius - Util.dip2px(context, 12);
        for (int i = 0; i <= 360; i += 30) {
            int x = (int) (pointDistance * Math.cos(Util.change(i))) + circleX;
            int y = (int) (pointDistance * Math.sin(Util.change(i))) + circleY;

            if (firstYellow) {
                canvas.drawCircle(x, y, Util.dip2px(context, 4), yellowPaint);
            } else {
                canvas.drawCircle(x, y, Util.dip2px(context, 4), whitePaint);
            }
            firstYellow = !firstYellow;
        }
    }

    public void rotate(int pos, int delayTime) {
        mTurnTableView.startRotate(pos);
        setDelayTime(delayTime);
        setStartBtnEnable(false);
    }

    public interface AnimationEndListener {
        void endAnimation(int position);
    }

    private AnimationEndListener listener;

    public void setAnimationEndListener(AnimationEndListener listener) {
        this.listener = listener;
    }

    public AnimationEndListener getAnimationEndListener() {
        return listener;
    }

    protected void setStartBtnEnable(boolean enable) {
        if (startBtn != null) {
            startBtn.setEnabled(enable);
        } else throw new RuntimeException("Have you add start button in LuckPanLayout element ?");
    }


    protected void setDelayTime(int delayTime) {
        this.delayTime = delayTime;
    }

}
